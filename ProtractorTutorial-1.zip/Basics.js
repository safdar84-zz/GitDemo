/**
 * 
 */
console.log("hello world");

//JavaScript is a dynamic type language, means you don't need to specify type of the variable because it is dynamically used by JavaScript engine. You need to use var here to specify the data type. It can hold any type of values such as numbers, strings etc

var a=4;
var b ="hello";
console.log(a);

console.log(b);
var c= "three";

//condition True
//execute the block of the code

//
//execute the another code
if(c=="one")
	{
	//code
	console.log("statement is true");
	
	}
else if (c=="two")
	{
		console.log("statement is two");
	}

else if (c=="three")
{
	console.log("statement is three");
}

else
	{
	console.log("Nothing is matched");
	}

	
var d ="Staddte";
var result;
switch(d)
{


case "Counddtry":
result = d;
break;


case "Staddtfe":
	result=d;
	break;
	

case "Staddte":
	result="hey am executing at 59th line";
	break;
	

case "Stadte":
	result=d;
	break;
	

case "State":
	result=d;
	break;
	

case "Statde":
	result=d;
	break;
	





}
console.log(result);






