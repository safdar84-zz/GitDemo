/**
 * 
 */


//'use strict';

module.exports = {
Alldata:{
firstData:{
		firstinput: "4",
secondinput:"3",
		result:"7"
},

secondData:{
		firstinput: "4",
		secondinput:"3",
				result:"7"
},


thirdData={
		firstinput: "4",
		secondinput:"3",
				result:"7"
}


}
}





	