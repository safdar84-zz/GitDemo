

     var obj=  require("./Jsobjectdemo.js");
     
     obj.getModel();
     console.log(obj.search);