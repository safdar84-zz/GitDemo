/**
 * 
 */

//print numbers from 1 to 100

for(var i=0;i<=100;i=i+5)
	{
	console.log(i);
	}

var j=1;
while (j<5)
{
	
console.log(j)
j++;
}
//***********************************************************************
var k =10;

do
	{
	console.log(k)
	k++;
	
	}while(k<6)
		
		