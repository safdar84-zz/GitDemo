require('../../modules/es6.date.to-json');
require('../../modules/es6.date.to-iso-string');
module.exports = require('../../modules/_core').Date.toISOString;