/**
 * http://usejsdoc.org/
 */

module.exports=
	{
Datadriven:
	{

FirstData:
	{
		firstinput:"2",
		secondinput:"3",
		result:"5"
		
	},

SecondData:
{
	firstinput:"5",
	secondinput:"4",
	result:"9"
	
},
ThirdData:
{
	firstinput:"5",
	secondinput:"2",
	result:"7"
	
}

	}

	}



