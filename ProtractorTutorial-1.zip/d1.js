/**
 * http://usejsdoc.org/
 */
	 var d=  require("./data.js");
	 console.log(d.datadrive.firstinput);